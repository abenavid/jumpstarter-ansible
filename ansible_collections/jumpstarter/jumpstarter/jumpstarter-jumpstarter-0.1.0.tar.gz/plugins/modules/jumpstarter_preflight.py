#!/usr/bin/python
from __future__ import annotations

DOCUMENTATION = r"""
---
module: jumpstarter_preflight
short_description: Validate Jumpstarter runtime prerequisites inside an Ansible execution environment
version_added: "0.1.0"
description:
  - Verifies that C(jmp) is available in PATH and returns its version.
  - Optionally verifies Jumpstarter config directories exist.
  - Optionally verifies a named exporter exists in Jumpstarter inventory.
  - Designed to run early in a play as a safety gate before any device operations.
options:
  exporter:
    description:
      - Exporter name to validate is available to Jumpstarter (for example, via C(/etc/jumpstarter/exporters)).
      - If provided and I(fail_on_missing_exporter) is true, the module fails when the exporter is not found.
    type: str
    required: false
  fail_on_missing_exporter:
    description:
      - When true, fail the task if I(exporter) is set and the exporter is not found.
    type: bool
    default: true
  check_config_dirs:
    description:
      - When true, validate config directories exist (or can be detected) inside the container.
      - Jumpstarter docs expect a user config directory and an exporter config directory.
    type: bool
    default: true
  user_config_dir:
    description:
      - Path to Jumpstarter user config directory (default aligns with Jumpstarter docs).
    type: str
    default: "~/.config/jumpstarter"
  exporters_dir:
    description:
      - Path to exporter configuration directory.
    type: str
    default: "/etc/jumpstarter/exporters"
  timeout:
    description:
      - Timeout in seconds for underlying C(jmp) commands.
    type: int
    required: false
author:
  - Jumpstarter Contributors
"""

EXAMPLES = r"""
- name: Preflight check before any device actions
  jumpstarter.jumpstarter.jumpstarter_preflight:
    exporter: test

- name: Only check that jmp exists, do not validate exporter or directories
  jumpstarter.jumpstarter.jumpstarter_preflight:
    check_config_dirs: false
    fail_on_missing_exporter: false
"""

RETURN = r"""
jmp_present:
  description: Whether C(jmp) was found and executed.
  type: bool
  returned: always
jmp_version:
  description: Output of C(jmp version) when available.
  type: str
  returned: always
user_config_dir:
  description: Resolved user config directory path.
  type: str
  returned: always
user_config_dir_exists:
  description: Whether user config directory exists.
  type: bool
  returned: always
exporters_dir:
  description: Exporters directory path.
  type: str
  returned: always
exporters_dir_exists:
  description: Whether exporters directory exists.
  type: bool
  returned: always
exporters:
  description: Exporter names discovered via C(jmp get exporters -o json), when available.
  type: list
  elements: str
  returned: always
exporter:
  description: Exporter name requested for validation.
  type: str
  returned: when exporter is provided
exporter_present:
  description: Whether requested exporter exists in discovered exporter list.
  type: bool
  returned: when exporter is provided
cmds:
  description: Commands executed during preflight.
  type: list
  elements: str
  returned: always
"""

import json
import os
from pathlib import Path

from ansible.module_utils.basic import AnsibleModule

from ansible_collections.jumpstarter.jumpstarter.plugins.module_utils.jumpstarter_common import (  # type: ignore[attr-defined]  # noqa: E501
    run_jmp,
)


def _expand_path(p: str) -> str:
    return os.path.expandvars(os.path.expanduser(p))


def _safe_path_exists(p: str) -> bool:
    try:
        return Path(p).exists()
    except Exception:
        return False


def _try_jmp_version(timeout: int | None) -> tuple[bool, str, str]:
    rc, stdout, stderr, cmd = run_jmp(args=["version"], timeout=timeout)
    if rc != 0:
        return False, "", f"{cmd}: {stderr.strip() or 'non zero rc'}"
    return True, stdout.strip(), ""


def _try_get_exporters(timeout: int | None) -> tuple[list[str], str | None]:
    rc, stdout, stderr, cmd = run_jmp(args=["get", "exporters", "-o", "json"], timeout=timeout)
    if rc != 0:
        return [], f"{cmd}: {stderr.strip() or 'non zero rc'}"

    try:
        data = json.loads(stdout)
    except Exception as exc:
        return [], f"failed to parse exporters json: {exc}"

    exporters: list[str] = []
    if isinstance(data, list):
        for item in data:
            if isinstance(item, dict) and isinstance(item.get("name"), str):
                exporters.append(item["name"])
    return exporters, None


def run_module() -> None:
    module_args = dict(
        exporter=dict(type="str", required=False),
        fail_on_missing_exporter=dict(type="bool", required=False, default=True),
        check_config_dirs=dict(type="bool", required=False, default=True),
        user_config_dir=dict(type="str", required=False, default="~/.config/jumpstarter"),
        exporters_dir=dict(type="str", required=False, default="/etc/jumpstarter/exporters"),
        timeout=dict(type="int", required=False),
    )

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True,
    )

    exporter = module.params.get("exporter")
    fail_on_missing_exporter = module.params["fail_on_missing_exporter"]
    check_config_dirs = module.params["check_config_dirs"]
    timeout = module.params.get("timeout")

    user_config_dir = _expand_path(module.params["user_config_dir"])
    exporters_dir = _expand_path(module.params["exporters_dir"])

    cmds: list[str] = []
    exporters: list[str] = []
    exporter_present: bool | None = None

    jmp_present, jmp_version, jmp_err = _try_jmp_version(timeout=timeout)
    cmds.append("jmp version")

    user_config_dir_exists = _safe_path_exists(user_config_dir) if check_config_dirs else False
    exporters_dir_exists = _safe_path_exists(exporters_dir) if check_config_dirs else False

    if not jmp_present:
        module.fail_json(
            msg="jmp not available or failed to execute",
            changed=False,
            jmp_present=False,
            jmp_version="",
            error=jmp_err,
            user_config_dir=user_config_dir,
            user_config_dir_exists=user_config_dir_exists,
            exporters_dir=exporters_dir,
            exporters_dir_exists=exporters_dir_exists,
            exporters=[],
            cmds=cmds,
        )

    exporters_err: str | None = None
    if exporter:
        cmds.append("jmp get exporters -o json")
        exporters, exporters_err = _try_get_exporters(timeout=timeout)
        exporter_present = exporter in exporters

        if exporters_err:
            module.fail_json(
                msg="failed to query exporters from jumpstarter",
                changed=False,
                jmp_present=True,
                jmp_version=jmp_version,
                error=exporters_err,
                user_config_dir=user_config_dir,
                user_config_dir_exists=user_config_dir_exists,
                exporters_dir=exporters_dir,
                exporters_dir_exists=exporters_dir_exists,
                exporters=exporters,
                exporter=exporter,
                exporter_present=exporter_present,
                cmds=cmds,
            )

        if fail_on_missing_exporter and not exporter_present:
            module.fail_json(
                msg=f"exporter not found: {exporter}",
                changed=False,
                jmp_present=True,
                jmp_version=jmp_version,
                user_config_dir=user_config_dir,
                user_config_dir_exists=user_config_dir_exists,
                exporters_dir=exporters_dir,
                exporters_dir_exists=exporters_dir_exists,
                exporters=exporters,
                exporter=exporter,
                exporter_present=exporter_present,
                cmds=cmds,
            )

    module.exit_json(
        changed=False,
        jmp_present=True,
        jmp_version=jmp_version,
        user_config_dir=user_config_dir,
        user_config_dir_exists=user_config_dir_exists,
        exporters_dir=exporters_dir,
        exporters_dir_exists=exporters_dir_exists,
        exporters=exporters,
        exporter=exporter,
        exporter_present=exporter_present,
        cmds=cmds,
    )


def main() -> None:
    run_module()


if __name__ == "__main__":
    main()
